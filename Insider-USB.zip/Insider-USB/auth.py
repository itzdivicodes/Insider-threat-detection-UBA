import streamlit as st
import bcrypt
from config import settings

def check_password():
    """Returns `True` if the user had the correct password."""
    def password_entered():
        """Checks whether a password entered by the user is correct."""
        if st.session_state["username"] == settings.ADMIN_USERNAME and \
           bcrypt.checkpw(st.session_state["password"].encode('utf-8'), 
                         settings.ADMIN_PASSWORD.encode('utf-8')):
            st.session_state["password_correct"] = True
            st.session_state["user"] = st.session_state["username"]
            del st.session_state["password"]  # Don't store the password
        else:
            st.session_state["password_correct"] = False

    # First run, show inputs for username + password.
    if "password_correct" not in st.session_state:
        st.text_input("Username", on_change=password_entered, key="username")
        st.text_input("Password", type="password", on_change=password_entered, key="password")
        return False
    # Password not correct, show input + error.
    elif not st.session_state["password_correct"]:
        st.text_input("Username", on_change=password_entered, key="username")
        st.text_input("Password", type="password", on_change=password_entered, key="password")
        st.error("😕 User not known or password incorrect")
        return False
    # Password correct.
    else:
        return True

def login_form():
    """Shows a login form with username and password fields."""
    st.title("🔒 Login to Insider Threat Detection")
    
    # Add some styling
    st.markdown("""
        <style>
            .stTextInput>div>div>input {
                border-radius: 20px;
                padding: 10px;
            }
            .stButton>button {
                width: 100%;
                border-radius: 20px;
                padding: 0.5rem 1rem;
            }
            .login-container {
                max-width: 400px;
                margin: 0 auto;
                padding: 2rem;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
        </style>
    """, unsafe_allow_html=True)
    
    with st.form("login_form"):
        st.markdown("<div class='login-container'>", unsafe_allow_html=True)
        
        # Username and password fields
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        # Login button
        submit_button = st.form_submit_button("Login")
        
        if submit_button:
            if username == settings.ADMIN_USERNAME and \
               password == settings.ADMIN_PASSWORD:  # In production, use proper password hashing
                st.session_state["authenticated"] = True
                st.session_state["username"] = username
                # Use experimental_rerun for better compatibility
                st.experimental_rerun()
            else:
                st.error("Invalid username or password")
        
        st.markdown("</div>", unsafe_allow_html=True)

def logout():
    """Logs out the current user."""
    if "authenticated" in st.session_state:
        del st.session_state["authenticated"]
    if "username" in st.session_state:
        del st.session_state["username"]
    if "model" in st.session_state:
        del st.session_state["model"]
    # Use experimental_rerun for better compatibility
    st.experimental_rerun()

def login_required(func):
    """Decorator to ensure user is logged in before accessing a page."""
    def wrapper(*args, **kwargs):
        if not st.session_state.get("authenticated", False):
            login_form()
            st.stop()
        return func(*args, **kwargs)
    return wrapper
