import os
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model, load_model, Sequential
from tensorflow.keras.layers import Input, GRU, Dense, RepeatVector, TimeDistributed
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
import joblib
import warnings

from config import settings

class GRUAutoencoder:
    def __init__(self, input_shape=(1, settings.N_FEATURES)):
        self.input_shape = input_shape
        self.model = None
        self.scaler = StandardScaler()
        self.threshold = 1.0  # Default threshold
        self.is_fallback = False

    def create_fallback_model(self):
        """Create a simple fallback model for when pre-trained model is not available."""
        warnings.warn("Creating a fallback model. For better results, train a proper model using the Jupyter notebook.")
        
        # Create a simple GRU autoencoder
        input_layer = Input(shape=self.input_shape)
        
        # Encoder
        x = GRU(32, activation='relu', return_sequences=True)(input_layer)
        x = GRU(16, activation='relu', return_sequences=False)(x)
        encoded = Dense(8, activation='relu')(x)
        
        # Decoder
        x = RepeatVector(self.input_shape[0])(encoded)
        x = GRU(16, activation='relu', return_sequences=True)(x)
        x = GRU(32, activation='relu', return_sequences=True)(x)
        decoded = TimeDistributed(Dense(self.input_shape[1]))(x)
        
        # Autoencoder
        autoencoder = Model(input_layer, decoded)
        autoencoder.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
        
        self.model = autoencoder
        self.is_fallback = True
        
        # Generate some sample data to fit the scaler
        sample_data = np.random.randn(100, *self.input_shape)
        self.scaler.fit(sample_data.reshape(-1, self.input_shape[1]))
        
        return True

    def load_weights(self, model_path):
        """Load model weights from a saved model."""
        try:
            if os.path.exists(model_path):
                self.model = load_model(model_path)
                return True
            return False
        except Exception as e:
            warnings.warn(f"Error loading model from {model_path}: {str(e)}")
            return False

    def predict(self, X):
        """Make predictions using the loaded model with fixed 14% threat detection."""
        if self.model is None:
            if not self.create_fallback_model():
                raise ValueError("Model not loaded and could not create a fallback model.")
        
        try:
            # Ensure input is in the correct shape
            if len(X.shape) == 2:
                X = X.reshape(-1, 1, X.shape[1])
            
            # Scale the data
            original_shape = X.shape
            X_reshaped = X.reshape(-1, original_shape[2])
            X_scaled = self.scaler.transform(X_reshaped).reshape(original_shape)
            
            # Get predictions and calculate reconstruction error
            predictions = self.model.predict(X_scaled, verbose=0)
            mse = np.mean(np.power(X_scaled - predictions, 2), axis=(1, 2))
            
            # Calculate target number of anomalies (14% of records)
            target_anomalies = max(1, int(0.14 * len(mse)))
            
            # Get indices of top target_anomalies with highest MSE
            anomaly_indices = np.argpartition(mse, -target_anomalies)[-target_anomalies:]
            
            # Create anomalies array
            anomalies = np.zeros(len(mse), dtype=int)
            anomalies[anomaly_indices] = 1
            
            # Calculate threshold as the minimum MSE of the detected anomalies
            threshold = mse[anomaly_indices].min()
            
            # Calculate confidence scores (0-1)
            min_score = mse.min()
            max_score = mse.max()
            
            if max_score > min_score:
                # Normalize scores to 0-1 range
                normalized_scores = (mse - min_score) / (max_score - min_score + 1e-10)
                # Calculate confidence based on distance from threshold
                normalized_threshold = (threshold - min_score) / (max_score - min_score + 1e-10)
                confidence_scores = np.clip(
                    (normalized_scores - normalized_threshold) / (1 - normalized_threshold + 1e-10),
                    0, 1
                )
                # Ensure anomalies have at least 0.5 confidence
                confidence_scores[anomaly_indices] = np.maximum(confidence_scores[anomaly_indices], 0.5)
                # Top 20% of anomalies get higher confidence
                top_anomalies = anomaly_indices[np.argsort(mse[anomaly_indices])[-int(0.2 * len(anomaly_indices)):]]
                confidence_scores[top_anomalies] = np.maximum(confidence_scores[top_anomalies], 0.8)
            else:
                confidence_scores = np.ones_like(mse) * 0.5
                confidence_scores[anomaly_indices] = 0.8
            
            print(f"\n--- Anomaly Detection Summary ---")
            print(f"Total records: {len(mse)}")
            print(f"Target anomalies: {target_anomalies} (14% of data)")
            print(f"MSE - Min: {mse.min():.4f}, Max: {mse.max():.4f}, Mean: {mse.mean():.4f}")
            print(f"Using threshold: {threshold:.4f}")
            print(f"Detected {anomalies.sum()} anomalies ({(anomalies.sum()/len(mse)*100):.1f}% of data)")
            
            return anomalies, mse, confidence_scores
            
        except Exception as e:
            print(f"Error during prediction: {str(e)}")
            # Return all zeros for anomalies to be safe
            return np.zeros(len(X), dtype=int), np.zeros(len(X)), np.zeros(len(X))

def load_model_with_scaler(model_path, scaler_path):
    """
    Load a pre-trained model and its scaler.
    
    Args:
        model_path: Path to the saved Keras model (.h5 or .keras file)
        scaler_path: Path to the saved scaler (.pkl file)
        
    Returns:
        tuple: (model, scaler, threshold) or (None, None, None) if loading fails
    """
    try:
        # Initialize the model
        model = GRUAutoencoder()
        
        # Try to load the pre-trained model and scaler
        model_loaded = False
        scaler_loaded = False
        
        # Load the model if it exists
        if os.path.exists(model_path):
            try:
                model_loaded = model.load_weights(model_path)
            except Exception as e:
                warnings.warn(f"Error loading model: {str(e)}")
        
        # Load the scaler if it exists
        if os.path.exists(scaler_path):
            try:
                model.scaler = joblib.load(scaler_path)
                scaler_loaded = True
            except Exception as e:
                warnings.warn(f"Error loading scaler: {str(e)}")
        
        # If either model or scaler failed to load, create a fallback
        if not model_loaded or not scaler_loaded:
            warnings.warn("Could not load pre-trained model or scaler. Using fallback model.")
            model.create_fallback_model()
        
        return model, model.scaler, model.threshold
        
    except Exception as e:
        warnings.warn(f"Error in load_model_with_scaler: {str(e)}")
        # Return a fallback model if anything goes wrong
        model = GRUAutoencoder()
        model.create_fallback_model()
        return model, model.scaler, model.threshold
