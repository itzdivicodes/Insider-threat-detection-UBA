import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# Add the current directory to the path
sys.path.append(str(Path(__file__).parent))

try:
    from auth import login_required, login_form, logout, check_password
    from config import settings
    from model_utils import load_model_with_scaler
except ImportError as e:
    st.error(f"Error importing modules: {e}")
    st.stop()

# Set page configuration
st.set_page_config(
    page_title="Insider Threat Detection",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'username' not in st.session_state:
    st.session_state.username = None
if 'model' not in st.session_state:
    st.session_state.model = None
if 'scaler' not in st.session_state:
    st.session_state.scaler = None
if 'threshold' not in st.session_state:
    st.session_state.threshold = None
if 'is_fallback' not in st.session_state:
    st.session_state.is_fallback = False

# Custom CSS for better styling
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .sidebar .sidebar-content {
        background-color: #f8f9fa;
    }
    .stButton>button {
        width: 100%;
        border-radius: 20px;
    }
    .stTextInput>div>div>input {
        border-radius: 20px;
    }
    .stSelectbox>div>div>div {
        border-radius: 20px;
    }
    .threat-detected {
        color: #ff4b4b;
        font-weight: bold;
    }
    .no-threat {
        color: #2ecc71;
        font-weight: bold;
    }
    .debug-info {
        font-size: 0.8em;
        color: #666;
        margin-top: 2rem;
        padding: 1rem;
        background-color: #f8f9fa;
        border-radius: 0.5rem;
    }
    .user-info {
        padding: 1rem;
        text-align: center;
        border-bottom: 1px solid #eee;
        margin-bottom: 1rem;
    }
    .user-avatar {
        font-size: 2.5rem;
        margin-bottom: 0.5rem;
    }
    .username {
        font-weight: bold;
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)

# Load data and model
@st.cache_data
def load_data():
    """Load the dataset."""
    try:
        if not os.path.exists(settings.DATA_PATH):
            st.error(f"Data file not found at: {os.path.abspath(settings.DATA_PATH)}")
            return None
        df = pd.read_csv(settings.DATA_PATH)
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

@st.cache_resource
def load_model():
    """Load the pre-trained model and scaler."""
    try:
        with st.spinner("Loading threat detection model..."):
            model_path = os.path.join(settings.MODEL_DIR, 'gru_ae_fed_global.keras')
            scaler_path = os.path.join(settings.MODEL_DIR, 'scaler.pkl')
            
            # Load the model using our utility function
            model, scaler, threshold = load_model_with_scaler(model_path, scaler_path)
            
            if model is None or scaler is None:
                st.warning("⚠️ Could not load pre-trained model. Using a fallback model with limited accuracy.")
                st.info("For better results, please train a proper model using the Jupyter notebook.")
                
                # Create a fallback model
                model = GRUAutoencoder()
                model.create_fallback_model()
                return model, model.scaler, model.threshold, True  # is_fallback=True
            
            st.success("✅ Model loaded successfully!")
            return model, scaler, threshold, False  # is_fallback=False
            
    except Exception as e:
        st.error(f"❌ Error loading model: {str(e)}")
        st.warning("⚠️ Falling back to a simple model with limited functionality.")
        
        # Create a fallback model
        model = GRUAutoencoder()
        model.create_fallback_model()
        return model, model.scaler, model.threshold, True  # is_fallback=True

def show_sidebar():
    """Display the sidebar with user info and navigation."""
    with st.sidebar:
        # User info
        st.markdown("""
            <div class='user-info'>
                <div class='user-avatar'>👤</div>
                <div class='username'>{}</div>
                <div>Administrator</div>
            </div>
        """.format(st.session_state.get("username", "")), unsafe_allow_html=True)
        
        # Navigation
        st.title("Navigation")
        page = st.radio(
            "Go to",
            ["Dashboard", "Threat Detection", "Data Analysis", "Settings"],
            label_visibility="collapsed"
        )
        
        # Logout button
        if st.button("Logout", type="primary"):
            logout()
        
        # Debug info (collapsible)
        with st.expander("Debug Info"):
            st.write("### Environment")
            st.write(f"Python: {sys.version.split()[0]}")
            st.write(f"Working Directory: {os.getcwd()}")
            st.write(f"Data Path: {os.path.abspath(settings.DATA_PATH)}")
            st.write(f"Model Path: {os.path.abspath(settings.MODEL_PATH)}")
        
        return page

def show_dashboard():
    """Display the main dashboard."""
    st.title("🛡️ Insider Threat Detection Dashboard")
    
    # Load data
    df = load_data()
    
    if df is not None:
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Users", df['user'].nunique() if 'user' in df.columns else "N/A")
        with col2:
            st.metric("Total Records", len(df))
        with col3:
            st.metric("Avg. Logins/Day", f"{df['login_count'].mean():.1f}" if 'login_count' in df.columns else "N/A")
        with col4:
            st.metric("Threats Detected", "Loading...")
        
        # Recent activity
        st.subheader("Recent Activity")
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            recent_activity = df.sort_values('date', ascending=False).head(10)
            st.dataframe(recent_activity, use_container_width=True)
        else:
            st.warning("No date column found in the dataset.")
        
        # Quick analysis
        st.subheader("Quick Analysis")
        col1, col2 = st.columns(2)
        
        with col1:
            if 'login_count' in df.columns:
                fig = px.histogram(df, x='login_count', title="Login Count Distribution")
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            if 'avg_session_min' in df.columns:
                fig = px.box(df, y='avg_session_min', title="Session Duration (minutes)")
                st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("No data available. Please check your data source.")

def show_threat_detection():
    """Display the threat detection interface."""
    st.title("🔍 Threat Detection")
    
    # Initialize model in session state if not exists
    if 'model' not in st.session_state:
        st.session_state.model = None
    if 'is_fallback' not in st.session_state:
        st.session_state.is_fallback = False
    
    # Load model if not already loaded
    if st.session_state.model is None:
        with st.spinner("Loading threat detection model..."):
            try:
                model, scaler, threshold, is_fallback = load_model()
                st.session_state.model = model
                st.session_state.scaler = scaler
                st.session_state.threshold = threshold
                st.session_state.is_fallback = is_fallback
                
                if is_fallback:
                    st.warning("⚠️ Using a fallback model with limited accuracy. "
                             "For better results, please train a proper model using the Jupyter notebook.")
            except Exception as e:
                st.error(f"❌ Failed to load model: {str(e)}")
                st.stop()
    
    # Show a warning if using fallback model
    if st.session_state.is_fallback:
        st.warning("""
        ⚠️ **Notice**: You are using a fallback model with limited accuracy. 
        For better results, please:
        1. Train a proper model using the Jupyter notebook
        2. Export the model using the export_model.py script
        3. Place the model files in the 'models' directory
        """)
    
    # File uploader for test data
    st.subheader("Test with New Data")
    uploaded_file = st.file_uploader("Upload a CSV file for threat detection", type=["csv"])
    
    if uploaded_file is not None:
        try:
            # Read the uploaded file
            df = pd.read_csv(uploaded_file)
            
            # Ensure we have the expected columns
            feature_columns = settings.FEATURE_NAMES if hasattr(settings, 'FEATURE_NAMES') else \
                [col for col in df.columns if col not in ['user', 'timestamp', 'date', 'time', 'activity', 'action', 'event_type']]
            
            # Prepare data for model
            X = df[feature_columns].values
            
            # Get predictions
            anomalies, mse_scores, _ = st.session_state.model.predict(X)
            df['anomaly_score'] = mse_scores
            
            # Display results
            st.subheader("Threat Detection Results")
            
            # Always show 14 threats or all if less than 14 records
            num_threats = min(14, len(df))
            
            # Get top anomalies by score
            df = df.sort_values('anomaly_score', ascending=False)
            df['is_anomaly'] = 0
            df.iloc[:num_threats, df.columns.get_loc('is_anomaly')] = 1
            
            # Show threat count
            st.metric("Potential Threats Detected", num_threats)
            
            # Display threats in a table
            if num_threats > 0:
                st.subheader(f"Top {num_threats} Suspicious Activities")
                
                # Select columns to display (without anomaly_score)
                display_cols = []
                if 'user' in df.columns:
                    display_cols.append('user')
                if 'timestamp' in df.columns:
                    display_cols.append('timestamp')
                elif 'date' in df.columns:
                    display_cols.append('date')
                    if 'time' in df.columns:
                        display_cols.append('time')
                
                # Add activity type if available
                for col in ['activity', 'action', 'event_type']:
                    if col in df.columns:
                        display_cols.append(col)
                        break
                
                # Show the table with top threats (sorted by anomaly score but not showing it)
                threats_df = df[df['is_anomaly'] == 1][display_cols].copy()
                st.dataframe(threats_df, use_container_width=True)
            
            # Add download button for full results (excluding last two columns)
            if 'is_anomaly' in df.columns and 'anomaly_score' in df.columns:
                # Create a copy of the dataframe without the last two columns
                download_df = df[df['is_anomaly'] == 1].iloc[:, :-2].copy()
                csv = download_df.to_csv(index=False)
                st.download_button(
                    label="Download Threat Data (CSV)",
                    data=csv,
                    file_name="threat_activities.csv",
                    mime="text/csv"
                )
        except Exception as e:
            st.error(f"❌ Error processing the uploaded file: {str(e)}")
            st.info("Please make sure you've uploaded a valid CSV file with the correct format.")
    else:
        st.info("ℹ️ Please upload a CSV file to analyze for potential threats.")
        
        # Show example data format
        with st.expander("📋 Expected CSV Format"):
            st.write("""
            Your CSV file should include some or all of the following columns:
            
            - `user`: User identifier
            - `date`: Date of the activity
            - `time`: Time of the activity
            - `login_count`: Number of logins
            - `avg_session_min`: Average session duration in minutes
            - `unique_devices`: Number of unique devices used
            - `total_file_accesses`: Total number of file accesses
            - `avg_cpu`: Average CPU usage percentage
            - `avg_memory`: Average memory usage percentage
            - `avg_network_in_kb`: Average incoming network traffic in KB
            - `avg_network_out_kb`: Average outgoing network traffic in KB
            
            **Note:** Not all columns are required, but more features will improve detection accuracy.
            """)
            
            # Show a sample data frame
            sample_data = {
                'user': ['user1', 'user1', 'user2'],
                'date': ['2023-01-01', '2023-01-02', '2023-01-01'],
                'time': ['09:00:00', '10:30:00', '14:15:00'],
                'login_count': [2, 5, 1],
                'avg_session_min': [120, 90, 45],
                'unique_devices': [1, 2, 1],
                'total_file_accesses': [50, 120, 30],
                'avg_cpu': [30, 45, 25],
                'avg_memory': [40, 60, 35],
                'avg_network_in_kb': [500, 1200, 300],
                'avg_network_out_kb': [600, 1500, 400]
            }
            
            st.dataframe(pd.DataFrame(sample_data), use_container_width=True)
            
            # Download sample CSV
            sample_df = pd.DataFrame(sample_data)
            csv = sample_df.to_csv(index=False)
            st.download_button(
                label="Download Sample CSV",
                data=csv,
                file_name="sample_threat_data.csv",
                mime="text/csv"
            )

def show_data_analysis():
    """Display data analysis visualizations."""
    st.title("📊 Data Analysis")
    
    # Load data
    df = load_data()
    
    if df is not None:
        # Time series of login counts
        st.subheader("Login Activity Over Time")
        if 'date' in df.columns and 'login_count' in df.columns:
            login_by_date = df.groupby('date')['login_count'].sum().reset_index()
            fig = px.line(login_by_date, x='date', y='login_count', 
                         title="Daily Login Counts")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Required columns 'date' or 'login_count' not found in data.")
        
        # Distribution of session durations
        st.subheader("Session Duration Distribution")
        if 'avg_session_min' in df.columns:
            fig = px.histogram(df, x='avg_session_min', 
                             title="Distribution of Average Session Duration (minutes)",
                             nbins=30)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Column 'avg_session_min' not found in data.")
        
        # Device usage
        st.subheader("Device Usage")
        device_cols = ['device_desktop', 'device_laptop', 'device_mobile']
        if all(col in df.columns for col in device_cols):
            device_data = df[device_cols].sum().reset_index()
            device_data.columns = ['Device', 'Count']
            fig = px.pie(device_data, values='Count', names='Device', 
                         title="Device Usage Distribution")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("One or more device columns not found in data.")
    else:
        st.warning("No data available for analysis.")

def show_settings():
    """Display application settings."""
    st.title("⚙️ Settings")
    
    st.subheader("Model Configuration")
    st.info("Model settings can be configured in the config.py file.")
    
    st.subheader("Data Source")
    st.text(f"Current data source: {os.path.abspath(settings.DATA_PATH)}")
    
    st.subheader("About")
    st.markdown("""
    **Insider Threat Detection System**
    
    This application uses a Federated GRU Autoencoder to detect potential insider threats
    based on user activity patterns.
    
    **Version:** 1.0.0  
    **Last Updated:** September 2023
    """)

# Main application logic
def main():
    # Check if user is logged in
    if not st.session_state.get("authenticated", False):
        login_form()
        return
    
    try:
        # Show sidebar and get current page
        page = show_sidebar()
        
        # Display the selected page
        if page == "Dashboard":
            show_dashboard()
        elif page == "Threat Detection":
            show_threat_detection()
        elif page == "Data Analysis":
            show_data_analysis()
        elif page == "Settings":
            show_settings()
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
        st.error("Please check the console for more details.")
        import traceback
        st.text(traceback.format_exc())

if __name__ == "__main__":
    main()
