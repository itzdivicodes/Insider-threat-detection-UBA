import os
from pathlib import Path
from dotenv import load_dotenv

# Get the absolute path of the current file
current_dir = Path(__file__).parent.absolute()

# Load environment variables from .env file
env_path = current_dir / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
else:
    print(f"Warning: .env file not found at {env_path}")

# Base directory
BASE_DIR = current_dir

# Application settings
class Settings:
    # Admin credentials
    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")  # Change this in production
    
    # File paths - using absolute paths
    DATA_DIR = current_dir / "data"
    MODEL_DIR = current_dir / "models"
    
    # Create directories if they don't exist
    DATA_DIR.mkdir(exist_ok=True, parents=True)
    MODEL_DIR.mkdir(exist_ok=True, parents=True)
    
    # File paths
    DATA_PATH = str(DATA_DIR / "merged_features.csv")
    
    # Model paths
    MODEL_PATH = str(MODEL_DIR / "gru_ae_fed_global.keras")  # Keras model format
    SCALER_PATH = str(MODEL_DIR / "scaler.pkl")  # Scaler for input features
    
    # Model parameters
    SEQUENCE_LENGTH = 1  # For GRU input shape
    N_FEATURES = 27  # Number of features in the model (updated to match the feature list)
    
    # Threshold for anomaly detection (this should match what was used during training)
    ANOMALY_THRESHOLD = 0.95  # 95th percentile
    
    # Feature names for reference (should match the order used during training)
    FEATURE_NAMES = [
        'login_count', 'mean_login_hour', 'mean_logout_hour',
        'avg_session_min', 'total_session_min', 'unique_devices',
        'unique_geo_locations', 'avg_login_day', 'weekend_logins',
        'total_file_accesses', 'category_authenticated', 'category_normal',
        'category_private', 'action_delete', 'action_read', 'action_write',
        'avg_daily_file_access', 'total_usage_min', 'avg_usage_min',
        'unique_apps', 'device_desktop', 'device_laptop', 'device_mobile',
        'avg_cpu', 'avg_memory', 'avg_network_in_kb', 'avg_network_out_kb',
        'avg_daily_app_usage'
    ]

# Create instance
settings = Settings()

# Create necessary directories
os.makedirs(settings.DATA_DIR, exist_ok=True)
os.makedirs(settings.MODEL_DIR, exist_ok=True)

# Print debug info
if __name__ == "__main__":
    print("=== Configuration Settings ===")
    print(f"Base Directory: {BASE_DIR}")
    print(f"Data Directory: {settings.DATA_DIR}")
    print(f"Model Directory: {settings.MODEL_DIR}")
    print(f"Data Path: {settings.DATA_PATH}")
    print(f"Model Path: {settings.MODEL_PATH}")
    print(f"Scaler Path: {settings.SCALER_PATH}")
    print(f"Number of Features: {settings.N_FEATURES}")
    print(f"Anomaly Threshold: {settings.ANOMALY_THRESHOLD}")
    print("============================")
