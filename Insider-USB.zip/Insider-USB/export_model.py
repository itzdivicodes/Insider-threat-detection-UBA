import os
import joblib
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import GRU, Dense, Input, RepeatVector, TimeDistributed
from sklearn.preprocessing import StandardScaler
import numpy as np
from pathlib import Path
import sys

# Add the current directory to the path
sys.path.append(str(Path(__file__).parent))

# Import config to get paths
from config import settings

def create_simple_model(input_shape=(1, settings.N_FEATURES)):
    """Create a simple GRU autoencoder model for fallback."""
    model = Sequential([
        Input(shape=input_shape),
        GRU(32, activation='relu', return_sequences=True),
        GRU(16, activation='relu', return_sequences=False),
        RepeatVector(input_shape[0]),
        GRU(16, activation='relu', return_sequences=True),
        GRU(32, activation='relu', return_sequences=True),
        TimeDistributed(Dense(input_shape[1]))
    ])
    model.compile(optimizer='adam', loss='mse')
    return model

def generate_sample_data(n_samples=1000, n_features=settings.N_FEATURES):
    """Generate sample data for training a fallback model."""
    print("Generating sample data for fallback model...")
    np.random.seed(42)
    
    # Generate random data with some structure
    X = np.random.randn(n_samples, n_features)
    
    # Add some anomalies (5% of data)
    n_anomalies = int(n_samples * 0.05)
    anomaly_indices = np.random.choice(n_samples, n_anomalies, replace=False)
    X[anomaly_indices] += 5.0  # Add large values to create anomalies
    
    # Reshape for GRU (samples, timesteps, features)
    X = X.reshape(-1, 1, n_features)
    return X

def create_fallback_model():
    """Create and train a simple fallback model."""
    print("Creating fallback model...")
    
    # Generate sample data
    X_train = generate_sample_data()
    
    # Create and train a simple model
    model = create_simple_model()
    model.fit(X_train, X_train, epochs=10, batch_size=32, verbose=0)
    
    # Create a simple scaler
    scaler = StandardScaler()
    scaler.fit(X_train.reshape(-1, X_train.shape[2]))
    
    return model, scaler, 1.0  # Return model, scaler, and a default threshold

def export_model_and_scaler(notebook_model_path, notebook_scaler_path):
    """
    Export the model and scaler from the Jupyter notebook to the correct format for the app.
    If the pre-trained files aren't found, creates a fallback model.
    """
    try:
        print("Starting model export process...")
        
        # Ensure output directories exist
        os.makedirs(settings.MODEL_DIR, exist_ok=True)
        
        # Check if we should use a fallback model
        use_fallback = False
        
        # 1. Check for existing model files
        if not os.path.exists(notebook_model_path) or not os.path.exists(notebook_scaler_path):
            print("Pre-trained model files not found.")
            response = input("Would you like to create a fallback model? (y/n): ").lower()
            if response != 'y':
                print("Exiting without creating model files.")
                return
            use_fallback = True
        
        if use_fallback:
            print("Creating a fallback model...")
            model, scaler, threshold = create_fallback_model()
            
            # Save the fallback model and scaler
            model.save(settings.MODEL_PATH)
            joblib.dump(scaler, settings.SCALER_PATH)
            
            print("\n✅ Fallback model and scaler created successfully!")
            print(f"- Model saved to: {settings.MODEL_PATH}")
            print(f"- Scaler saved to: {settings.SCALER_PATH}")
            print("\n⚠️  WARNING: This is a simple fallback model with limited accuracy.")
            print("   For better results, please train a proper model using the Jupyter notebook.")
            return
        
        # 2. Load and verify the pre-trained model and scaler
        print("Loading pre-trained model and scaler...")
        
        # Load the model
        model = load_model(notebook_model_path)
        
        # Load the scaler
        scaler = joblib.load(notebook_scaler_path)
        
        # Save in the format expected by the app
        output_model_path = settings.MODEL_PATH
        model.save(output_model_path)
        output_scaler_path = settings.SCALER_PATH
        joblib.dump(scaler, output_scaler_path)
        
        print("\n✅ Model and scaler loaded successfully!")
        print(f"- Model: {output_model_path}")
        print(f"- Scaler: {output_scaler_path}")
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("\nFalling back to creating a simple model...")
        
        # Create a fallback model if anything goes wrong
        model, scaler, _ = create_fallback_model()
        model.save(settings.MODEL_PATH)
        joblib.dump(scaler, settings.SCALER_PATH)
        
        print("\n✅ Created and saved a fallback model!")
        print(f"- Model: {settings.MODEL_PATH}")
        print(f"- Scaler: {settings.SCALER_PATH}")
        print("\n⚠️  WARNING: This is a simple fallback model with limited accuracy.")

if __name__ == "__main__":
    print("=== Model Export Tool ===")
    print("This script helps manage the threat detection model for the Insider Threat Detection app.")
    print("It will look for pre-trained model files or create a fallback model if needed.\n")
    
    # Default paths - update these to match your notebook's output
    default_model = os.path.join(os.path.dirname(__file__), "models", "gru_ae_fed_global.keras")
    default_scaler = os.path.join(os.path.dirname(__file__), "models", "scaler.pkl")
    
    # Get paths from user or use defaults
    notebook_model = input(f"Path to notebook model file [{default_model}]: ") or default_model
    notebook_scaler = input(f"Path to notebook scaler file [{default_scaler}]: ") or default_scaler
    
    # Run the export
    export_model_and_scaler(notebook_model, notebook_scaler)
