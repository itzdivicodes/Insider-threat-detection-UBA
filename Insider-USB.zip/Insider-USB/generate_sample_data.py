import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path

# Get the current directory
current_dir = Path(__file__).parent.absolute()
data_dir = current_dir / 'data'
data_dir.mkdir(exist_ok=True)

def generate_sample_data(num_records=1000):
    """Generate sample data for testing the application."""
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate timestamps for the last 30 days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    dates = [start_date + timedelta(days=x) for x in range((end_date - start_date).days)]
    
    # Generate user IDs
    user_ids = [f'user_{i:03d}' for i in range(1, 11)]
    
    # Create empty dataframe
    data = []
    
    for date in dates:
        for user in user_ids:
            # Generate random but somewhat realistic values
            login_count = np.random.randint(1, 10)
            avg_session_min = np.random.normal(30, 15)
            avg_session_min = max(1, min(avg_session_min, 120))  # Clamp between 1 and 120 minutes
            
            record = {
                'date': date.strftime('%Y-%m-%d'),
                'user': user,
                'login_count': login_count,
                'mean_login_hour': np.random.normal(9, 2),  # Around 9 AM
                'mean_logout_hour': np.random.normal(17, 2),  # Around 5 PM
                'avg_session_min': avg_session_min,
                'total_session_min': login_count * avg_session_min,
                'unique_devices': np.random.randint(1, 4),
                'unique_geo_locations': np.random.randint(1, 3),
                'avg_login_day': np.random.uniform(1, 5),
                'weekend_logins': np.random.randint(0, 3),
                'total_file_accesses': np.random.poisson(50),
                'category_authenticated': np.random.randint(5, 20),
                'category_normal': np.random.randint(10, 40),
                'category_private': np.random.randint(0, 10),
                'action_delete': np.random.randint(0, 5),
                'action_read': np.random.randint(30, 100),
                'action_write': np.random.randint(5, 30),
                'avg_daily_file_access': np.random.poisson(50),
                'total_usage_min': np.random.normal(240, 60),  # Around 4 hours
                'avg_usage_min': avg_session_min,
                'unique_apps': np.random.randint(3, 10),
                'device_desktop': np.random.choice([0, 1], p=[0.3, 0.7]),
                'device_laptop': np.random.choice([0, 1], p=[0.5, 0.5]),
                'device_mobile': np.random.choice([0, 1], p=[0.7, 0.3]),
                'avg_cpu': np.random.uniform(10, 80),
                'avg_memory': np.random.uniform(20, 90),
                'avg_network_in_kb': np.random.gamma(2, 300),
                'avg_network_out_kb': np.random.gamma(1, 200),
                'avg_daily_app_usage': np.random.normal(120, 30)  # Around 2 hours
            }
            
            # Add some anomalies (5% of records)
            if np.random.random() < 0.05:
                record['login_count'] = np.random.randint(20, 50)  # Unusually high login count
                record['avg_network_out_kb'] = np.random.gamma(5, 1000)  # High network usage
                record['action_delete'] = np.random.randint(5, 20)  # More deletes than usual
            
            data.append(record)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Ensure all numeric columns are actually numeric
    numeric_cols = df.columns.difference(['date', 'user'])
    df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce')
    
    return df

if __name__ == "__main__":
    print("Generating sample data...")
    output_path = data_dir / 'merged_features.csv'
    
    # Generate and save sample data
    sample_data = generate_sample_data()
    sample_data.to_csv(output_path, index=False)
    
    print(f"Sample data generated successfully with {len(sample_data)} records")
    print(f"Saved to: {output_path}")
    print("\nFirst few rows:")
    print(sample_data.head())
