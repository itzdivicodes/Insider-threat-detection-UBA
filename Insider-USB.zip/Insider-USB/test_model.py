import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path

# Add the current directory to the path
current_dir = Path(__file__).parent.absolute()
sys.path.append(str(current_dir))

def test_model_loading():
    """Test the model loading and training process."""
    print("=== Testing Model Loading ===")
    
    try:
        from model_utils import load_or_train_model
        from config import settings
        
        print(f"Data path: {settings.DATA_PATH}")
        print(f"Model path: {settings.MODEL_PATH}")
        
        # Check if data file exists
        if not os.path.exists(settings.DATA_PATH):
            print("\n❌ Error: Data file not found!")
            print(f"Please make sure the file exists at: {settings.DATA_PATH}")
            print("You can generate sample data using: python generate_sample_data.py")
            return False
            
        print("\n✅ Data file found. Loading or training model...")
        
        # Load or train the model
        model = load_or_train_model(
            data_path=settings.DATA_PATH,
            model_path=settings.MODEL_PATH,
            force_retrain=False  # Set to True to force retraining
        )
        
        if model is None:
            print("\n❌ Failed to load or train the model.")
            return False
            
        print("\n✅ Model loaded/trained successfully!")
        print("\nModel information:")
        print(f"- Type: {type(model).__name__}")
        
        # Test making a prediction
        print("\nTesting prediction with sample data...")
        try:
            # Create sample input (1 sample, 1 timestep, N features)
            sample_input = np.random.randn(1, 1, 24)  # 24 features as per our model
            prediction = model.predict(sample_input)
            
            if isinstance(prediction, tuple) and len(prediction) == 2:
                anomalies, scores = prediction
                print(f"✅ Prediction successful!")
                print(f"- Anomalies shape: {anomalies.shape if hasattr(anomalies, 'shape') else 'N/A'}")
                print(f"- Scores shape: {scores.shape if hasattr(scores, 'shape') else 'N/A'}")
                print(f"- Sample prediction: Anomaly={anomalies[0] if hasattr(anomalies, '__getitem__') else anomalies}, Score={scores[0] if hasattr(scores, '__getitem__') else scores}")
            else:
                print(f"✅ Prediction successful! Output: {prediction}")
                
            return True
            
        except Exception as e:
            print(f"\n❌ Error during prediction: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    except Exception as e:
        print(f"\n❌ Error during model testing: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=== Model Loading Test ===\n")
    
    # Test model loading
    success = test_model_loading()
    
    # Print summary
    print("\n=== Test Summary ===")
    if success:
        print("✅ All tests passed! The model is working correctly.")
        print("\nYou can now run the Streamlit app with: streamlit run app.py")
    else:
        print("❌ Some tests failed. Please check the error messages above.")
        print("\nTroubleshooting tips:")
        print("1. Make sure you have generated the sample data: python generate_sample_data.py")
        print("2. Check that you have all required packages installed: pip install -r requirements.txt")
        print("3. Verify that the data file exists at the expected location")
        print("4. Check for any error messages in the output above")
