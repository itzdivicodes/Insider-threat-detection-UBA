import os
import sys
from pathlib import Path

# Add the current directory to the path
current_dir = Path(__file__).parent.absolute()
sys.path.append(str(current_dir))

def test_config():
    print("\n=== Testing Configuration ===")
    try:
        from config import settings
        print(f"✅ Config loaded successfully")
        print(f"Current directory: {current_dir}")
        print(f"Data path: {settings.DATA_PATH}")
        print(f"Model path: {settings.MODEL_PATH}")
        print(f"Data directory exists: {os.path.exists(os.path.dirname(settings.DATA_PATH))}")
        print(f"Model directory exists: {os.path.exists(os.path.dirname(settings.MODEL_PATH))}")
        return True
    except Exception as e:
        print(f"❌ Error loading config: {e}")
        return False

def test_data_loading():
    print("\n=== Testing Data Loading ===")
    try:
        from app import load_data
        df = load_data()
        if df is not None:
            print(f"✅ Data loaded successfully with {len(df)} rows")
            print("\nFirst few rows:")
            print(df.head())
            return True
        else:
            print("❌ Failed to load data")
            return False
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return False

if __name__ == "__main__":
    print("Starting configuration and data loading tests...")
    
    # Run tests
    config_ok = test_config()
    data_ok = test_config() and test_data_loading()
    
    # Print summary
    print("\n=== Test Summary ===")
    print(f"Configuration: {'✅ PASSED' if config_ok else '❌ FAILED'}")
    print(f"Data Loading: {'✅ PASSED' if data_ok else '❌ FAILED'}")
    
    if not (config_ok and data_ok):
        print("\nTroubleshooting Tips:")
        if not config_ok:
            print("- Check if .env file exists in the project root")
            print("- Verify that DATA_PATH and MODEL_PATH in .env are correct")
        if not data_ok:
            print("- Make sure merged_features.csv exists in the data directory")
            print("- Check file permissions for the data directory")
