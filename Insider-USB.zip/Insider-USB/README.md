# Insider Threat Detection System

A Streamlit-based web application for detecting potential insider threats using machine learning.

## Features

- 🔐 User authentication with JWT tokens
- 📊 Interactive data visualization
- 🚨 Real-time threat detection
- 📱 Responsive design for all devices
- 📈 Data analysis dashboard

## Prerequisites

- Python 3.8+
- pip (Python package manager)

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd Insider-USB
   ```

2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Set up environment variables:
   - Copy `.env.example` to `.env`
   - Update the values in `.env` as needed

## Running the Application

1. Start the Streamlit application:
   ```bash
   streamlit run app.py
   ```

2. Open your web browser and navigate to:
   ```
   http://localhost:8501
   ```

3. Log in using the default credentials:
   - Username: admin
   - Password: admin123

## Project Structure

- `app.py` - Main Streamlit application
- `auth.py` - Authentication and user management
- `config.py` - Application configuration
- `requirements.txt` - Python dependencies
- `.env` - Environment variables (not committed to version control)
- `merged_features.csv` - Sample dataset
- `Merged-dataset-model.ipynb` - Jupyter notebook with model training code

## Usage

### Overview
- View key metrics and sample data
- Get a quick summary of the dataset

### Data Analysis
- Explore login activity over time
- Analyze session duration distribution
- View device usage statistics

### Threat Detection
- Input user activity data
- Get real-time threat predictions
- View feature importance for predictions

## Security Notes

- Change the default admin credentials in production
- Store sensitive information in environment variables
- Use HTTPS in production
- Regularly update dependencies for security patches

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Streamlit for the amazing web framework
- Scikit-learn for machine learning tools
- Plotly for interactive visualizations
