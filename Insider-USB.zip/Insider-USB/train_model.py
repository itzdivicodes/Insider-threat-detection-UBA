import os
import sys
import logging
import argparse
from pathlib import Path

# Add the current directory to the path
sys.path.append(str(Path(__file__).parent))

from model_utils import load_or_train_model
from config import settings

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Train the federated GRU autoencoder model.')
    parser.add_argument('--data-path', type=str, default=settings.DATA_PATH,
                      help=f'Path to the training data CSV (default: {settings.DATA_PATH})')
    parser.add_argument('--model-path', type=str, default=settings.MODEL_PATH,
                      help=f'Path to save the trained model (default: {settings.MODEL_PATH})')
    parser.add_argument('--force-retrain', action='store_true',
                      help='Force retraining even if a model already exists')
    parser.add_argument('--n-clients', type=int, default=3,
                      help='Number of clients for federated learning (default: 3)')
    return parser.parse_args()

def main():
    """Main function to train the model."""
    args = parse_args()
    
    logger.info("Starting model training...")
    logger.info(f"Data path: {args.data_path}")
    logger.info(f"Model will be saved to: {args.model_path}")
    logger.info(f"Number of federated clients: {args.n_clients}")
    
    # Ensure the output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(args.model_path)), exist_ok=True)
    
    try:
        # Load or train the model
        model = load_or_train_model(
            data_path=args.data_path,
            model_path=args.model_path,
            force_retrain=args.force_retrain
        )
        
        if model is not None:
            logger.info("Model training completed successfully!")
            logger.info(f"Model saved to {os.path.abspath(args.model_path)}")
        else:
            logger.error("Model training failed!")
            sys.exit(1)
            
    except Exception as e:
        logger.exception(f"An error occurred during model training: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
