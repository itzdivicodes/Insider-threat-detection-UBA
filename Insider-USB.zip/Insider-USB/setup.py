import os
import sys
from pathlib import Path

def setup_project():
    """Set up the project directory structure and verify requirements."""
    print("Setting up Insider Threat Detection project...")
    
    # Get the current directory
    current_dir = Path(__file__).parent.absolute()
    
    # Define required directories
    dirs = [
        current_dir / 'data',
        current_dir / 'models',
        current_dir / 'logs'
    ]
    
    # Create directories if they don't exist
    for directory in dirs:
        directory.mkdir(exist_ok=True)
        print(f"✓ Created directory: {directory}")
    
    # Check if .env file exists
    env_path = current_dir / '.env'
    if not env_path.exists():
        # Create default .env file
        with open(env_path, 'w') as f:
            f.write("""# Admin credentials
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123

# File paths (relative to project root)
DATA_PATH=data/merged_features.csv
MODEL_PATH=models/federated_gru_autoencoder.pkl
""")
        print(f"✓ Created default .env file at: {env_path}")
    
    # Check if requirements.txt exists
    req_path = current_dir / 'requirements.txt'
    if not req_path.exists():
        print("❌ requirements.txt not found. Please create it with the required packages.")
    else:
        print(f"✓ Found requirements.txt at: {req_path}")
    
    # Check if sample data exists
    data_path = current_dir / 'data' / 'merged_features.csv'
    if not data_path.exists():
        print("ℹ️ No data file found. You can generate sample data using generate_sample_data.py")
    else:
        print(f"✓ Found data file at: {data_path}")
    
    print("\nSetup complete!")
    print("Next steps:")
    print("1. Install requirements: pip install -r requirements.txt")
    print("2. Generate sample data: python generate_sample_data.py")
    print("3. Run the app: streamlit run app.py")

if __name__ == "__main__":
    setup_project()
